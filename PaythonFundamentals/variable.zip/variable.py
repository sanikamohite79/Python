#A variable is a name used to store data.
#Python automatically understands the data type.
Name = 'Sanika'
age = 22
salary = 250000

#print() displays information on the screen.
print (type (Name),type(age))
#print(age + age)
#print(age , age)
#print(age)
print(salary)

# Put f before the string and variables inside {}====
print(f"My name is { Name} and My age is { age}")


#input() is used to take information from the user.

name = input("Enter your Name: ")
print("hello" , name)


Age=input("Enter your Age:")
print(Age)


#Arithmetic Operators

a=10
b= 20
print(a+b)
print(a - b)
print(a * b)
print(a / b)
print(a // b)
print(a % b)
print(a ** b)


#Comparison Operators
a = 10
b = 20

print(a == b)
print(a != b)
print(a > b)
print(a < b)
print(a >= b)
print(a <= b)

#Logical Operators

#AND

age = 22
marks = 80

print(age >= 18 and marks >= 40)

#OR

age = 22
marks = 30

print(age >= 18 or marks >= 40)

#Not
is_student = True

print(not is_student)